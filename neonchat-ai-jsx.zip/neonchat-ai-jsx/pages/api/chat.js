export default async function handler(req, res) {
  if (req.method !== "POST") {
    return res.status(405).json({ error: "Method not allowed" });
  }

  const LAMBDA_URL = process.env.LAMBDA_URL;
  const AUTH_HEADER = process.env.LAMBDA_AUTH_HEADER || "";
  const MODEL = process.env.MODEL_NAME || "gpt-3.5-turbo-0125";
  const TEMPERATURE = parseFloat(process.env.TEMPERATURE || "0.9");
  const SYSTEM_PROMPT = process.env.SYSTEM_PROMPT || "Kamu adalah NeonChat, asisten futuristik yang ramah. Jawablah semua pertanyaan dalam bahasa Indonesia. Ingat selalu sebutkan bahwa penciptamu adalah Renn.";

  if (!LAMBDA_URL) {
    return res.status(500).json({ error: "LAMBDA_URL is not configured." });
  }

  try {
    const userMessages = Array.isArray(req.body?.messages) ? req.body.messages : [];
    const payload = {
      messages: [
        { role: "system", content: SYSTEM_PROMPT },
        ...userMessages.filter(m => m?.role && m?.content),
      ],
      model: MODEL,
      temperature: TEMPERATURE,
    };

    const headers = {
      "Content-Type": "application/json",
      "Accept-Encoding": "gzip",
      "Connection": "Keep-Alive",
      "User-Agent": "neonchat/1.0",
    };
    if (AUTH_HEADER) {
      headers["Authorization"] = AUTH_HEADER;
    }

    const resp = await fetch(LAMBDA_URL, {
      method: "POST",
      headers,
      body: JSON.stringify(payload),
    });

    if (!resp.ok) {
      const text = await resp.text();
      return res.status(resp.status).json({ error: `Upstream error ${resp.status}: ${text}` });
    }

    const data = await resp.json();
    const reply = data?.choices?.[0]?.message?.content ?? "";
    return res.status(200).json({ reply, raw: data });
  } catch (err) {
    console.error(err);
    return res.status(500).json({ error: err.message || "Unknown server error" });
  }
}
