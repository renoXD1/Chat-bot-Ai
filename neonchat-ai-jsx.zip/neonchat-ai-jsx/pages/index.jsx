import Head from "next/head";
import ChatUI from "../components/ChatUI.jsx";

export default function Home() {
  return (
    <>
      <Head>
        <title>NeonChat AI</title>
        <meta name="description" content="Futuristic Neon Chat AI by Renn" />
      </Head>
      <main className="min-h-screen bg-gradient-to-br from-black via-gray-900 to-black text-white flex flex-col items-center">
        <h1 className="text-4xl md:text-5xl font-bold mt-8 mb-4 text-neon-blue neon-glow">
          NeonChat AI <span className="text-neon-green">by Renn</span>
        </h1>
        <p className="mb-6 text-gray-300">Asisten Futuristik Berbahasa Indonesia</p>
        <div className="w-full max-w-3xl">
          <ChatUI />
        </div>
      </main>
    </>
  );
}
