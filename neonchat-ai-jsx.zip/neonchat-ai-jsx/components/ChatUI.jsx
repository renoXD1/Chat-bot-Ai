import { useState } from "react";
import { motion } from "framer-motion";

export default function ChatUI() {
  const [messages, setMessages] = useState([]);
  const [input, setInput] = useState("");
  const [loading, setLoading] = useState(false);

  const sendMessage = async () => {
    if (!input.trim()) return;
    const newMessages = [...messages, { role: "user", content: input }];
    setMessages(newMessages);
    setInput("");
    setLoading(true);

    try {
      const res = await fetch("/api/chat", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ messages: newMessages }),
      });
      const data = await res.json();
      if (data.reply) {
        setMessages([...newMessages, { role: "assistant", content: data.reply }]);
      } else {
        setMessages([...newMessages, { role: "assistant", content: "Maaf, terjadi kesalahan." }]);
      }
    } catch (err) {
      setMessages([...newMessages, { role: "assistant", content: "Error: " + err.message }]);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="bg-gray-900 bg-opacity-60 rounded-2xl shadow-xl p-4 flex flex-col h-[70vh]">
      <div className="flex-1 overflow-y-auto space-y-4 mb-4 scrollbar-thin scrollbar-thumb-neon-blue scrollbar-track-gray-700">
        {messages.map((msg, idx) => (
          <motion.div
            key={idx}
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            className={`p-3 max-w-[80%] rounded-2xl ${
              msg.role === "user"
                ? "ml-auto bg-neon-purple text-white"
                : "mr-auto bg-neon-blue text-black"
            }`}
          >
            {msg.content}
          </motion.div>
        ))}
        {loading && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            className="mr-auto bg-neon-blue text-black p-3 rounded-2xl max-w-[60%] animate-pulse"
          >
            ...
          </motion.div>
        )}
      </div>
      <div className="flex space-x-2">
        <input
          type="text"
          value={input}
          onChange={(e) => setInput(e.target.value)}
          onKeyDown={(e) => e.key === "Enter" && sendMessage()}
          placeholder="Ketik pesanmu..."
          className="flex-1 p-3 rounded-2xl bg-black border border-neon-blue text-white focus:outline-none focus:ring-2 focus:ring-neon-green"
        />
        <button
          onClick={sendMessage}
          className="px-4 py-2 rounded-2xl bg-neon-green text-black font-bold shadow-lg hover:opacity-90 transition"
        >
          Kirim
        </button>
      </div>
    </div>
  );
}
